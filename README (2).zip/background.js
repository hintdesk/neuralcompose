// background.js
// Entry point for the NeuralCompose Thunderbird extension

browser.runtime.onInstalled.addListener(() => {
  console.log("NeuralCompose extension installed.");
});
